import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
// @ts-ignore
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.4'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CognitoForm {
  id: string;
  name: string;
}

interface FormEntry {
  id: string;
  form_id: string;
  form_name: string;
  status: string;
  created_utc: string;
  completed_utc: string;
  data: any;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { userId } = await req.json()
    
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? ''
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    const supabase = createClient(supabaseUrl, supabaseKey)

    // Get CognitoForms credentials
    const cognitoApiKey = Deno.env.get('COGNITO_API_KEY')
    const cognitoOrgId = Deno.env.get('COGNITO_ORG_ID')
    
    if (!cognitoApiKey || !cognitoOrgId) {
      throw new Error('CognitoForms credentials not configured')
    }

    // Fetch all forms for the organization
    const formsResponse = await fetch(
      `https://www.cognitoforms.com/api/v1/organizations/${cognitoOrgId}/forms`,
      {
        headers: {
          'Authorization': `Bearer ${cognitoApiKey}`,
          'Content-Type': 'application/json'
        }
      }
    )

    if (!formsResponse.ok) {
      throw new Error(`Failed to fetch forms: ${await formsResponse.text()}`)
    }

    const forms: CognitoForm[] = await formsResponse.json()
    
    let totalCreated = 0
    let totalUpdated = 0

    // Process each form
    for (const form of forms) {
      // Fetch entries for this form
      const entriesResponse = await fetch(
        `https://www.cognitoforms.com/api/v1/forms/${form.id}/entries`,
        {
          headers: {
            'Authorization': `Bearer ${cognitoApiKey}`,
            'Content-Type': 'application/json'
          }
        }
      )

      if (!entriesResponse.ok) {
        console.error(`Failed to fetch entries for form ${form.name}: ${await entriesResponse.text()}`)
        continue
      }

      const entries: FormEntry[] = await entriesResponse.json()

      // Process each entry
      for (const entry of entries) {
        // Extract fields from the entry data
        const data = entry.data || {}
        
        // Common field name patterns
        const clientName = extractClientName(data)
        const companyName = data.companyName || 
                          data.businessName || 
                          data.legalCompanyName ||
                          data.company ||
                          'Unknown Company'
        
        const loanAmount = extractLoanAmount(data)
        const dateSubmitted = entry.completed_utc || entry.created_utc || new Date().toISOString()
        
        // Map status based on CognitoForms status or custom fields
        const status = determineStatus(entry.status, data)
        
        // Extract other relevant fields
        const email = data.email || data.emailAddress || data.contactEmail || ''
        const phone = data.phone || data.phoneNumber || data.contactPhone || ''
        const loanType = data.loanType || data.fundingType || 'Working Capital'
        const industry = data.industry || data.businessIndustry || ''
        const revenue = data.revenue || data.annualRevenue || data.monthlyRevenue || 0
        const timeInBusiness = data.timeInBusiness || data.yearsInBusiness || ''
        const address = formatAddress(data.address || data.businessAddress || data)
        
        // Check if deal already exists
        const { data: existingDeal } = await supabase
          .from('deals')
          .select('id')
          .eq('cognito_entry_id', entry.id)
          .eq('user_id', userId)
          .single()
        
        const dealData = {
          user_id: userId,
          date_submitted: dateSubmitted,
          loan_type: loanType,
          legal_company_name: companyName,
          client_name: clientName,
          loan_amount: loanAmount,
          status: status,
          source: 'cognitoforms',
          cognito_entry_id: entry.id,
          form_id: entry.form_id,
          form_name: form.name,
          form_data: data, // Store complete form data
          email: email,
          phone: phone,
          address: address,
          industry: industry,
          revenue: revenue,
          time_in_business: timeInBusiness
        }
        
        if (existingDeal) {
          // Update existing deal
          const { error } = await supabase
            .from('deals')
            .update(dealData)
            .eq('id', existingDeal.id)
          
          if (error) {
            console.error('Error updating deal:', error)
          } else {
            totalUpdated++
          }
        } else {
          // Create new deal
          const { error } = await supabase
            .from('deals')
            .insert(dealData)
          
          if (error) {
            console.error('Error creating deal:', error)
          } else {
            totalCreated++
          }
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        created: totalCreated, 
        updated: totalUpdated,
        forms: forms.length 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )
  } catch (error) {
    console.error('CognitoForms sync error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    )
  }
})

// Helper functions

function extractClientName(data: any): string {
  // Check for different name field patterns
  if (data.name) {
    if (typeof data.name === 'string') return data.name
    if (data.name.first && data.name.last) return `${data.name.first} ${data.name.last}`
    if (data.name.firstName && data.name.lastName) return `${data.name.firstName} ${data.name.lastName}`
  }
  
  if (data.firstName && data.lastName) return `${data.firstName} ${data.lastName}`
  if (data.contactName) return data.contactName
  if (data.applicantName) return data.applicantName
  
  return 'Unknown Client'
}

function extractLoanAmount(data: any): number {
  // Check different amount field patterns
  const amount = data.loanAmount || 
                data.requestedAmount || 
                data.amount ||
                data.fundingAmount ||
                data.amountRequested ||
                0
  
  // Handle string amounts with currency symbols
  if (typeof amount === 'string') {
    return parseFloat(amount.replace(/[^0-9.-]+/g, '')) || 0
  }
  
  return parseFloat(amount) || 0
}

function determineStatus(entryStatus: string, data: any): string {
  // Map CognitoForms status to our status options
  const statusMap: Record<string, string> = {
    'completed': 'Application Submitted',
    'submitted': 'Application Submitted',
    'in_progress': 'Reviewing',
    'pending': 'Reviewing',
    'approved': 'Approved',
    'funded': 'Funded',
    'denied': 'Denied',
    'rejected': 'Denied',
    'incomplete': 'More Information Needed'
  }
  
  // Check entry status first
  if (entryStatus && statusMap[entryStatus.toLowerCase()]) {
    return statusMap[entryStatus.toLowerCase()]
  }
  
  // Check for status field in data
  if (data.status && statusMap[data.status.toLowerCase()]) {
    return statusMap[data.status.toLowerCase()]
  }
  
  // Default status
  return 'Application Submitted'
}

function formatAddress(addressData: any): string {
  if (typeof addressData === 'string') return addressData
  
  if (addressData && typeof addressData === 'object') {
    const parts = []
    if (addressData.line1 || addressData.addressLine1) parts.push(addressData.line1 || addressData.addressLine1)
    if (addressData.line2 || addressData.addressLine2) parts.push(addressData.line2 || addressData.addressLine2)
    if (addressData.city) parts.push(addressData.city)
    if (addressData.state || addressData.stateProvince) parts.push(addressData.state || addressData.stateProvince)
    if (addressData.postalCode || addressData.zipCode) parts.push(addressData.postalCode || addressData.zipCode)
    if (addressData.country) parts.push(addressData.country)
    
    return parts.filter(Boolean).join(', ')
  }
  
  return ''
}
```
